<?php
include('connect.php');
if(isset($_GET['catid']))
{
if(!is_numeric($_GET['catid']))
{
$error=true;
$errormsg="Serious error. Contact webmaster:Invalid Category id entered: ".$_GET['catid'];
}
else
{
$error=false;
$aID=mysql_escape_string($_GET['catid']);
$query="SELECT * from books INNER JOIN genre ON genID=gen_id WHERE genID='".$aID."'";
$results=mysql_query($query);
if($results)
{
$num=mysql_num_rows($results);
}
else
{
$error=true;
$errormsg.=mysql_error();
}
}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Book Store</title>
<link rel="stylesheet" type="text/css" href="mystyle.css"/>
</head>

<body>
<?php
if(!$error){
?>
<table width="100%" border="0">
 <tr>
  <td colspan="3"><h1>Pleasure Reading Inc.</h1></td>
  </tr>
 <tr>
  <td colspan="4"></td>
 </tr>
  <td colspan="4"><b><?php trim(stripslashes($_SESSION['catname']))?></b></td>
 </tr>
 <tr>
  <td width="10%"></td>
  <td width="90%"></td>
  </tr>
  <?php
  if($num>0)
  {
  while($rowb=mysql_fetch_assoc($results))
  {
  ?>
  <tr>
   <td bgcolor="#CCCCCC"><strong>Title:</strong></td>
   <td><a href="bookdetails.php?bid=<?php echo $rowb['book_id']?>" ><?php echo trim(stripslashes(    $rowb['title'])) ?></a></td>
   </tr>
   <tr>
     <td bgcolor="#CCCCCC"><strong>Price:</strong></td>
	 <td><?php echo "$".trim(stripslashes(    $rowb['price'])) ?></td>
	</tr> 
	<tr>
	 <td colspan="2"><hr/></td>
	 </tr>
	 <?php
	 }
	  }else{
	  ?>
	 <tr>
	  <td colspan="2"></td>
	 </tr>
	 <tr>
	  <td colspan="2"><p>There are no books in this category.</p></td>
	 </tr>
	 <?php
	 }
	 ?>
	 </table>
	 <?php
	  }else{
	  ?>
	  <table>
	  <tr>
	    <td><p><?php echo "The following error occurred: ".$errormsg." " ?></p></td>
	  </tr>
	 </table>
	 <?php
	 }
	 ?> 
</body>
</html>
 