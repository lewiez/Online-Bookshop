<?php
include('connect.php');
$query="select * from genre";
$results=mysql_query($query);
if($results)
{
$num=mysql_num_rows($results);
}
else
{
echo mysql_error();
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Book Categories</title>
<link href="mystyle.css" rel="stylesheet" type="text/css" />
<style type="text/css">

</style>
</head>

<body>
<div id="menu">
  <div id="logo">
  <?php
	include("logo.php");
  ?> 
  </div>

  <div id="menu_bar">
    <?php
	include("menu.php");
	?>
  </div>
</div>

<div id="left_sub_menu">
  <p align="left"><a href="#"></a> </p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
<div id="book_categories">
<h2>Welcome to e-Lem</h2>
<p>e-Lem is the number one online bookshop in Kenya and East Africa. You order the books of your choice online
   and they will be brought to the door-step of your house. Start using it today!</p>
  <table width="99%" border="0">
    <tr>
      <td><h3>Book Genre</h3></td>
    </tr>
    <?php
 if($num>0)
 {
 while($row=mysql_fetch_assoc($results))
  {
   ?>
    <tr>
      <td bgcolor="white"></td>
    </tr>
    <tr>
      <td bgcolor="white"><a style="color:#33CCFF; font-size:14px; text-decoration:none;" href="book_listing.php?catid=<?php echo $row['gen_id'];?>">
        <?php
	echo $row['gen_name'];?>
      </a></td>
    </tr>
    <tr>
      <td><?php
	echo $row['descpt'];
	?>
      </td>
    </tr>
    <?php
   }
   }
   else{
   ?>
    <tr>
      <td>No categories available.</td>
    </tr>
    <?php
    }
	?>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <div id="back_button">
   <div align="center">
    </div>
 </div>
</div>

<div id="right_sub_menu">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>

<div id="footer">
<?php
  include("footer.php");
?>
</div>
</body>
</html>

