<?php
session_start();
?>
<?php
include("connect.php");
$myusername=mysql_real_escape_string($_POST['myusername']);
$mypassword=mysql_real_escape_string($_POST['mypassword']);

$sql="SELECT * FROM users WHERE username='$myusername' and password='$mypassword'";
$result=mysql_query($sql);

$count=mysql_num_rows($result);

if($count==1)
{
//session_register("myusername");
//session_register("mypassword");

header("location: online_bookshop.php");
}
else
{
echo "Wrong username and password";
}
?>

