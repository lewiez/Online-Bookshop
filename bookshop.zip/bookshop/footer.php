<?php
echo '<span align="center">Copyright &copy; www.e-Lem.com 2017</span><br/>
  <span align="center">Terms &amp; Conditions apply  </span>';
?>