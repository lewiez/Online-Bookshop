<?php
mysql_connect("localhost", "root", null);
mysql_select_db("bookshop");
?>