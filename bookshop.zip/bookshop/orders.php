<?php
session_start();
?>
<?php
include "connect.php";
?>
<?php
$PHPSESSID=session_id();
if(isset($_POST['submit']))
{
$order_name=mysql_escape_string($_POST['o_name']);
$order_address=mysql_escape_string($_POST['address']);
$order_total=mysql_escape_string($_POST['total']);

$order_date=mysql_escape_string($_POST['o_date']);
$order_status=mysql_escape_string($_POST['status']);

$addorder="INSERT INTO orders SET order_name='".$order_name."', order_address='".$order_address."', order_total='".$order_total."', order_date='".$order_date."', order_status='".$order_status."'";
$result=mysql_query($addorder);
if(!$result)
{
$msg=mysql_error();
}
else
{
$msg="Your order has been processed. Thank you for shopping with us!";
}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Checkout</title>
<link href="mystyle.css" rel="stylesheet" type="text/css" />
<style type="text/css">

</style>
</head>

<body>
<div id="menu">
  <div id="logo">
   <?php
	include("logo.php");
  ?>
  </div>
  <div id="menu_bar">
    <?php
	include("menu.php");
	?>
  </div>
 
  
</div>
<
<div id="orders">
  <table width="98%" border="0">
<tr>
 <td colspan="2"><h1 class="style10">Order Checkout</h1>
   </td>
 </tr>
 <?php if(!isset($msg)) {?>
 <form action="orders.php" method="post">
 <tr>
 <td width="16%">Name</td>
 <td width="84%"><label><input name="o_name" type="text" size="40" required/></label></td>
 </tr>
 <tr>
  <td valign="top">Address</td>
  <td><label>
  	<textarea name="address" required></textarea>
	</label></td>
</tr>
<tr>
<td>Total</td>
<td><label>
  <input name="total" type="text" size="40" value="<?php echo $_SESSION['gtotal']; ?>" />
  </label></td>
  </tr>
  
 <tr>
   <td>Date</td>
   <td><label> 
        <input name="o_date" type="text" size="40" value="<?php echo date("Y/m/d");?>"/>
		</label></td>
</tr>
<tr>
<td>Status</td>
<td><label>
<select name="status">  
   <option>processed</option>
   <option>pending</option>
</select>
</label></td>
</tr>
<tr>
<td style="text-align:right;">
  <label><button type="submit" class="btn" name="submit" onmouseover="btnOver(this)" onmouseout="btnNormal(this)">Send Order</button></label>
</td>
<td></td>
 <td></td>
</tr>
</form>
<?php
}
else
{
?>
	<tr>
	<td><?php echo $msg; ?></td>
	</tr>
<?php
}
?>
</table>
<div id="back_button">
   <div align="center">
     
    </div>
 </div>
</div>

<div id="right_sub_menu">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>

<div class="back">
  <?php
  include("back.php");
  ?>
</div>

<div id="footer">
<?php
  include("footer.php");
?>
</div>
<?php
include("btn-styles.php");
?>
</body>
</html>

