<?php
session_start();
?>
<?php
include "connect.php";
$PHPSESSID=session_id();
if(isset($_GET['cid']))
{
$cleancid=mysql_escape_string($_GET['cid']);
$removefromcart="DELETE FROM cart_track WHERE cart_id='".$cleancid."' AND session_id='".$PHPSESSID."'";
mysql_query($removefromcart);
header("location:showcart.php");
}
else
{
header("location:errorpage.php?errorno=1");
}
?>