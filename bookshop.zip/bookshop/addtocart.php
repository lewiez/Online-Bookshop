<?php
session_start();
include('connect.php');
if(!is_numeric($_POST['bid']))
{
$error=true;
$errormsg="Security, Serious error. Contact webmaster: bid entered: ".$_POST['bid'];
}
else
{
$cbID=mysql_escape_string($_POST['bid']);
}
$bidcheck="SELECT title FROM books WHERE book_id='".$cbID."'";
$result=mysql_query($bidcheck);
if(!$result)
{
$err=true;
header("location:index.php");
}

if(!is_numeric($_POST['qty']))
{
$err=true;
}
else
{
$cqty=mysql_escape_string($_POST['qty']);
}
if(!$err)
{
$PHPSESSID=session_id();
$addtocart="INSERT INTO cart_track SET session_id='".$PHPSESSID."',bid='".$cbID."', date_added='".$td."', qtty='".$_POST['qty']."'";
mysql_query($addtocart);
header("location:showcart.php");
exit;
}
ob_end_flush()
?>









