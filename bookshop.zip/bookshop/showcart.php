<?php
session_start();
?>
<?php
include('connect.php');
if(isset($_POST['checkout']))
{
header("location:orders.php");
}
if(isset($_POST['shop']))
{
header("location:index.php");
}
$PHPSESSID=session_id();
$showcart="SELECT * from cart_track INNER JOIN books ON bid=book_id WHERE session_id='".$PHPSESSID."'";
$result=mysql_query($showcart);
if(!$result)
{
$err=true;
$errmsg=mysql_error();
}
else
{
$err=false;
$num=mysql_num_rows($result);
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Shopping Cart</title>
<link href="mystyle.css" rel="stylesheet" type="text/css" />
<style type="text/css">

</style>
</head>

<body>
<div id="menu">
  <div id="logo">
   <?php
	include("logo.php");
  ?>
  </div>
  <div id="menu_bar">
    <?php
	include("menu.php");
	?>
  </div>
  
</div>
<p>&nbsp;	</p>
<div id="show_cart">
  <table width="95%" border="0">
<tr>
 <td colspan="5"><h1 class="style10">Shopping Cart</h1></td>
</tr>
<tr>
  <td> </td>
  <td> </td>
  <td> </td>
  <td> </td>
  <td> </td>
</tr>
<?php 
if(!$err)
{
?>
<tr>
	<td bgcolor="#33CCFF"><strong>Book Title</strong></td>
	<td bgcolor="#33CCFF"><strong>Qty</strong></td>
	<td bgcolor="#33CCFF"><strong>Price</strong></td>
	<td bgcolor="#33CCFF"><strong>Total</strong></td>
	<td bgcolor="#33CCFF"><strong>Action</strong></td>
</tr>
<?php
$gtotal=0;
 if($num>0)
 {
 while($row=mysql_fetch_assoc($result))
 {
 ?>
 <tr>
  <td><?php echo trim(stripslashes($row['title']))?></td>
  <td><?php echo trim(stripslashes($row['qtty']))?></td>	
  <td><?php echo trim(stripslashes($row['price']))?></td>	
  <td><?php
      $total=$row['qtty']* $row['price'];
 	
	  $gtotal=$gtotal+ $total;
	  $_SESSION['gtotal']=$total;
	  echo "$".$total;?>
   </td>
   <td><a href="delete.php?cid=<?php echo $row['cart_id']?>" >Remove</a></td>
   </tr>
  <?php
  }
  }else{
  ?>
  <tr>
  <td colspan="5"><p>There are no items in your shopping cart.</p></td>
  </tr>
  <?php
  }
  ?>
  <tr>
  <td></td>	
  <td></td>
  </tr>
  <form action="showcart.php" method="post">
  <tr>
    <td><label></label></td>
	<td></td>
	<td><button type="submit" class="btn" name="checkout" onmouseover="btnOver(this)" onmouseout="btnNormal(this)">Check Out</button></td>
  
	<td> </td>
	</tr>
	</form>
	<?php
	}
	else
	{
	?>
	<td colspan="5">
	<p><?php echo $errmsg;?></p>
	</td>
	</tr>
	<?php
	}
	?>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <div id="back_button">
   <div align="center">
     
    </div>
 </div>
</div>
 <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>

<div id="right_sub_menu">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
<div class="back">
  <?php
  include("back.php");
  ?>
</div>
<div id="footer">
<?php
  include("footer.php");
?>
</div>
<?php
include("btn-styles.php");
?>
</body>
</html>

