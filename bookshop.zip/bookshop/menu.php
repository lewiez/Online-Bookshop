<?php
echo '<a href="index.php">Home</a> 
 <a href="about_us.php">About Us</a> 
 <a href="contact_us.php">Contact Us</a>';
 ?>