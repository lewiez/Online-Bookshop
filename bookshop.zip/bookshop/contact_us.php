<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Contact Us</title>
<link href="mystyle.css" rel="stylesheet" type="text/css" />
<style type="text/css">

</style>
</head>

<body>
<div id="menu">
  <div id="logo">
   <?php
	include("logo.php");
  ?>
  </div>
  <div id="menu_bar">
   <?php
	include("menu.php");
	?>
  </div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
<div id="content">
<h1>Contact Us</h1>
 <address>
<p id="addr">
Postal Address: P. O Box 623-00600 Nairobi, Kenya<br><br>
Tel: 0702 831080 , 0738 831081 , 0717 883779<br><br>
Email: lewisbookshop@gmail.com<br><br>
<br>
</p>
</address>
   <div id="back_button">
   <div align="center">
     <p>
       <script>
function goBack()
{
window.history.back()
}
  </script>
       
       <input type="button" value="&lt;&lt;&nbsp;Back" onclick="goBack()" />
     </p>
    </div>
 </div>
</div>
<div id="footer">
<?php
  include("footer.php");
?>
</div>
</body>
</html>
