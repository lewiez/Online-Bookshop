<?php
echo '<script>
function btnOver(x){
  x.style.backgroundColor="white";
  x.style.color="blue";
}

function btnNormal(x){
  x.style.backgroundColor="blue";
  x.style.color="white";
}

function backOver(x){
  x.style.backgroundColor="white";
  x.style.color="#33CCFF";
}

function backNormal(x){
  x.style.backgroundColor="#33CCFF";
  x.style.color="white";
}
</script>';
?>