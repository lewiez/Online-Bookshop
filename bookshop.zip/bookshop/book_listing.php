<?php
session_start();
?>
<?php
include('connect.php');
if(isset($_GET['catid']))
{
if(!is_numeric($_GET['catid']))
{
$error=true;
$errormsg="Serious error. Contact webmaster:Invalid Category id entered: ".$_GET['catid'];
}
else
{
$error=false;
$aID=mysql_escape_string($_GET['catid']);
$query="SELECT * from books INNER JOIN genre ON genID=gen_id WHERE genID='".$aID."'";
$results=mysql_query($query);
if($results)
{
$num=mysql_num_rows($results);
}
else
{
$error=true;
$errormsg.=mysql_error();
}
}
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Book Listing</title>
<link href="mystyle.css" rel="stylesheet" type="text/css" />
<style type="text/css">

</style>
</head>

<body>
<div id="menu">
  <div id="logo">
    <?php
	include("logo.php");
  ?>
  </div>
  <div id="menu_bar">
    <?php
	include("menu.php");
	?>
  </div>
 
</div>

<div id="left_sub_menu">
  <p align="center"><a href="#"></a> </p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
<div id="book_listing">

<?php
if(!$error){
?>

<table width="79%" border="0">
 <tr>
  <td colspan="3"><h1 class="style10">Books Listing</h1></td>
  </tr>
 <tr>
  <td colspan="4"></td>
 </tr>
 
 <tr>
  <td width="10%"></td>
  <td width="90%"></td>
  </tr>
  <?php
  if($num>0)
  {
  while($rowb=mysql_fetch_assoc($results))
  {
  ?>
  <tr>
   <td bgcolor="#33CCFF"><strong>Title:</strong></td>
   <td><a style="color:#33CCFF;" href="book_details.php?bid=<?php echo $rowb['book_id']?>" ><?php echo trim(stripslashes(    $rowb['title'])) ?></a></td>
   </tr>
   <tr>
     <td bgcolor="#33CCFF"><strong>Price:</strong></td>
	 <td><?php echo "$".trim(stripslashes( $rowb['price'])) ?></td>
	</tr> 
	<tr>
	 <td colspan="2"><p>&nbsp;</p>
                     
      </td>
    </tr>
	 <?php
	 }
	  }else{
	  ?>
	 <tr>
	  <td colspan="2"></td>
	 </tr>
	 <tr>
	  <td colspan="2"><p>There are no books in this category.</p></td>
	 </tr>
	 <?php
	 }
	 ?>
  </table>
	 <?php
	  }else{
	  ?>
	  <table>
	  <tr>
	    <td><p><?php echo "The following error occurred: ".$errormsg." " ?></p></td>
	  </tr>
	 </table>
	  <p>
	    <?php
	 }
	 ?>
  </p>
	  <p>&nbsp;	            </p>
	  <div id="back_button">
   <div align="center">
     <p>
       <script>
function goBack()
{
window.history.back()
}
  </script>
       
       <input type="button" value="&lt;&lt;&nbsp;Back" onclick="goBack()" />
     </p>
    </div>
 </div>
</div>

<div id="right_sub_menu">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
<p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  
<div id="footer">
 <?php
  include("footer.php");
?>
</div>
</body>
</html>

