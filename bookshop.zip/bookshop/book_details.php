<?php
include('connect.php');
$error=" ";
$errormsg=" ";
if(isset($_GET['bid']))
{
if(!is_numeric($_GET['bid']))
{
$error=true;
$errormsg="Security, Serious error. Contact webmaster:Invalid Category id entered: ".$_GET['bid'];
}
else
{
$cbID=mysql_escape_string($_GET['bid']);
$query="SELECT * from books INNER JOIN genre ON genID=gen_id WHERE book_id='".$cbID."'";
$results=mysql_query($query);
if($results)
{
$num=mysql_num_rows($results);
$row=mysql_fetch_assoc($results);
$authno=$row['authID'];

if($authno>0)
{
$query_auth="SELECT * from author WHERE auth_id='".$authno."'";
$results_auth=mysql_query($query_auth);
$row_auth=mysql_fetch_assoc($results_auth);
$auth=$row_auth['auth_name'];
}
}
else{
$error=true;
$errormsg.=mysql_error();
}
}
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Book Details</title>
<link href="mystyle.css" rel="stylesheet" type="text/css" />
<style type="text/css">

</style>
</head>

<body>
<div id="menu">
  <div id="logo">
    <?php
	include("logo.php");
  ?>
  </div>
  <div id="menu_bar">
    <?php
  include("menu.php");
  ?>
  </div>
  
</div>
<p>&nbsp;	</p>
<div id="left_sub_menu">
  <p align="center"><a href="#"></a> </p>
 
</div>
<div id="book_details">
  <table width="98%" border="0" >
 <tr>
  <td colspan="3"><h1 class="style16">Book Details</h1></td>
 </tr>
  <tr>
   <td> </td>
 </tr>
 <tr>
   <td width="12%"> </td>
   <td width="19%"> </td>
   <td width="69%"> </td>
 </tr>
 <tr>
    <td rowspan="5" valign="top"><img src="images/<?php echo $row['book_img'];?>" height="100" width="100" style="margin-right:50px;" /></td>
	<td> </td>
	<td> </td>
  </tr>
  <tr>
    <td><strong>Price: </strong></td>
	<td><?php echo "$".$row['price']; ?></td>
   </tr>
   <tr>
    <td><strong>ISBN: </strong></td>
	<td><?php echo $row['ISBN']; ?></td>
   </tr>

    <tr>
    <td><strong>Publication Date: </strong></td>
	<td><?php echo $row['publicationdate']; ?></td>
   </tr>
   <tr>
    <td><strong>Author: </strong></td>
	<td><?php echo $auth; ?></td>
   </tr>
   <form action="addtocart.php" method="post">
   <tr>
     <td> </td>
	 <td><strong>Quantity</strong></td>
	 <td><label>
	   <select name="qty">
	 <?php
	 for($i=1; $i<12; $i++)
	 {
	 echo '<option value= '.$i.'>'.$i.'</option>';
	 }
	 ?>
	 </select>
	   </label>	   </td>
	   <input name="bid" type="hidden" value="<?php echo $row['book_id']?>" />
	   </td>
      </tr>
	   <tr>
	   <td> </td>
	   <td> </td>
	   <td>
     <label><button type="submit" class="btn" name="submit" onmouseover="btnOver(this)" onmouseout="btnNormal(this)">Add to Cart</button></label>
     </td>
	   </tr>
    </form>
  </table>
  <div id="back_button">
   <div align="center">
     
    </div>
 </div>
</div>
<div id="right_sub_menu">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
<div class="back">
  <?php
  include("back.php");
  ?>
</div>
<div id="footer">
<?php
  include("footer.php");
?>
</div>
<?php
include("btn-styles.php");
?>
</body>
</html>

