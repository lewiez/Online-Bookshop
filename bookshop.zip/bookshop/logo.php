<?php
echo '<a href="index.php"><img src="images/logo.png" height="80" width="200"/></a>';
?>