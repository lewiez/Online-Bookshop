<?php
echo '<p>
 <script>
    function goBack(){window.history.back()}
 </script>
 <button type="submit" class="btn-back" name="submit"  onclick="goBack()" onmouseover="backOver(this)" onmouseout="backNormal(this)">&lt;&lt;&nbsp;Back</button>
</p>';
?>





