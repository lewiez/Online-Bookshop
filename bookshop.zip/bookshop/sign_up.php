<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Online Bookshop</title>
<link href="mystyle.css" rel="stylesheet" type="text/css" />
<style type="text/css">

</style>
</head>

<body>
<div id="menu">
  <div id="logo">
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
  <div id="menu_bar">
    <p><a href="#">About Us</a> <a href="index.php">Home</a> <a href="online_bookshop.php">Online Bookshop</a> <a href="#">Blog</a> </p>
    <p>&nbsp;</p>
  </div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
<p>&nbsp;	</p>
<div id="sign_up_page">
  <form id="form1" name="form1" method="post" action="">
    <p><fieldset><legend><strong>Sign up</strong></legend>
    <p>
      <label><strong>Username:</strong><br />	
      <input type="text" name="textfield" />
      </label>
      <span class="style12">&nbsp;*Please use your email address for username </span></p>
    <p>
      <label><strong>Password</strong>:<br />	
      <input type="text" name="textfield2" />
      </label>
      &nbsp;</p>
    <p>
      <label>
      <input type="submit" name="Submit" value="Sign up" />
      </label>
    </p>
    <p><span class="style13">*</span><span class="style11">By signing up, you will be eligible to subscribe to our newsletters via your email address.</span></p>
    <p><span class="style13">*</span><span class="style11">Therefore it would be better to use your email address as your username. </span></p>
    <p class="style11">&nbsp;</p>
    </fieldset>
    �</form>
  </div>
 <div id="content">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <div id="back_button">
   <div align="center">
     <p>
       <script>
function goBack()
{
window.history.back()
}
  </script>
       
       <input type="button" value="&lt;&lt;&nbsp;Back" onclick="goBack()" />
     </p>
    </div>
 </div>
</div>
  <div id="footer">
<?php
  include("footer.php");
?>
</div>
</body>
</html>
